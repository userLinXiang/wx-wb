// pages/cart/cart.js
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    url:app.globalData.url,
    cartList:[],
    userName:app.globalData.userName,
    values:[],
    allValue:'0',
    allChecked:false,
    uid:app.globalData.uid
  },
  //获取购物车商品信息
  getCart:function(){
    wx.request({
      url: this.data.url+'getCart',
      data:{uid:this.data.uid},
      header: {
        'Content-Type': 'application/json'
      },
      success: (res)=>{
        //console.log(res)
        this.setData({
          cartList:res.data
        })
      }
    }) 
  },
  //删除按钮绑定 删除对应元素
  delItem:function(e){
    //console.log(e);
    wx.showModal({
      title: '是否删除该商品？',
      success:(res)=>{
        if(res.cancel){

        }else{
          var index=e.target.dataset.index;
          var list=this.data.cartList;
          var lid=list[index].pid;
          list.splice(index,1);
          this.setData({
            cartList:list
          })
          wx.request({
            url: this.data.url+'delete',
            header: {
              'Content-Type': 'application/json'
            },
            data:{lid:lid,uid:this.data.uid},
            success: function(res) {
              //console.log(res)
              var msg=res.msg;
              wx.showToast({
                title: msg,
                icon: 'none',
                duration:2000
              })
            }
          })
        }
      }
    })
    
  
    //console.log(list);
  },
  // 去登录
  login:function(){
    wx.wx.navigateTo({
      url: '/pages/login/login'
    })
  },
  // 去逛逛 为了关闭当前页面 redirectTo
  shop:function(){
    wx.navigateTo({
      url: '/pages/product/product'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      this.getCart()
  },
  changeBind:function(event){
    console.log(event)
    var total=0;
    this.setData({
      values:event.detail.value
    })
    for(var i=0;i<this.data.values.length;i++){
      total+=parseInt(this.data.values[i])
    }
    this.setData({
      allValue:total
    })
  },
  allChecked:function(event){
    //console.log(event)
    var total=0;
    var list=this.data.cartList;
    if(event.detail.value.length>0){
      this.checkBox(true,list)
      for(var i=0;i<list.length;i++){
        total+=(parseInt(list[i].price)*parseInt(list[i].count))
      }
      this.setData({
        allValue:total
      })
    }else{
      this.checkBox(false,list)
      this.setData({
        allValue:0
      })
    }
    
  },
  checkBox:function(ischecked,list){
    for(var i=0;i<list.length;i++){
      list[i].ischecked=ischecked;
    }
    this.setData({
      cartList:list
    })
  },
  flash:function(){
    this.getCart()
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})