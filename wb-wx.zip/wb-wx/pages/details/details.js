// pages/details/details.js
const app=getApp();
Page({
  countInput:function(e){
    this.setData({
      inputValue:e.detail.value
    })
  },
  countAdd:function(){
    this.setData({
      inputValue:++this.data.inputValue
    }) 
  },
  countReduce:function(){
    if(this.data.inputValue>1){
    this.setData({
      inputValue:--this.data.inputValue
    })
  }
  },
  // 加入购物车的方法 首先判断是否登录 确认登录后 才进行加入购物车
  joinCart:function(){
    var back=this.getPage();
    if(this.data.userName==''){
      wx.showToast({
        title:"您未登录，请先登录！",
        icon:"none",
        duration:2000
      })
      setTimeout(()=>{
        wx.navigateTo({
          url: '/pages/login/login?back='+back+"&lid="+this.data.lid
        })
      },2000)
    }else{
      wx.request({
        url:this.data.url+'joinCart',
        data:{lid:this.data.lid,count:this.data.inputValue,uid:this.data.uid},
        success:(res)=>{
          console.log(res);
        }
      })
      wx.showToast({
        title: '加入购物车成功',
        icon: '',
        duration:2000
      })
    }
  },
  // 获取当前页面路径，为了登录后能够返回之前的页面
  getPage:function(){
    var pages = getCurrentPages();
    var currentPage = pages[pages.length-1];
    var url = currentPage.route;
    return url;
    //console.log(back);
  },
  // 立即购买，出现一个提示框'很抱歉，该功能还未实现'
  pay:function(){
    wx.showToast({
      title: '很抱歉，该功能还未实现！',
      icon: 'none',
      duration:2000
    })
  },
  /**
   * 页面的初始数据
   */
  data: {
    url:app.globalData.url,
    inputValue:1,
    product:[],
    spec:[],
    lid:1,
    userName:app.globalData.userName,
    uid:app.globalData.uid
  },
  //接收跳转到详情页面的参数，并发起网络请求，保存数据
  getDetails:function(lid){
    wx.request({
      url: this.data.url+'getDetails',
      data:{lid},
      header: {
        'Content-Type': 'application/json'
      },
      success: (res)=>{
        //console.log(res)
        this.setData({
          product:res.data.product,
          spec:res.data.spec
        })
        //console.log(this.data.product);
        //console.log(this.data.spec);
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var lid=options.lid;
    this.setData({
      lid:lid
    })
    this.getDetails(lid);
    //console.log(app.globalData.userInfo)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})