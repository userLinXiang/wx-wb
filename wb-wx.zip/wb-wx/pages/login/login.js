// pages/login/login.js
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    uname:'',
    upwd:'',
    url:app.globalData.url,
    back:'',
    lid:'',
    userName:'',
    avatarUrl:''
  },
  // 获取input的用户名 保存数据
  getUname:function(event){
    //console.log(event.detail);
    this.setData({
      uname:event.detail.value
    })
  },
  // 获取input的密码 保存数据
  getUpwd:function(event){
    this.setData({
      upwd:event.detail.value
    })
  },
  //登录按钮  登录 并跳转返回之前页面 或者返回主页
  login:function(){
    var uname=this.data.uname;
    var upwd=this.data.upwd;
    wx.request({
      url: this.data.url+'signin',
      method:"POST",
      data:{uname:uname,upwd:upwd},
      header: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      success:(res)=> {
        console.log(res);
        var msg=res.data.msg;
        if(res.data.ok==0){
          wx.showToast({
            title: msg,
            icon: 'none',
            duration:2000
          })
        }else if(res.data.ok==1){
          this.setData({
            userName:res.data.uname
          })
          app.globalData.userName = res.data.uname;
          app.globalData.uid=res.data.uid;
          wx.showToast({
            title: '登录成功',
            icon: 'none',
            duration:2000
          })
          setTimeout(this.JumbBack,2000)
        }
      }
    })
  },
  //创建一个跳转函数
  JumbBack:function(){
    var back=this.data.back;
    var lid=this.data.lid;
    var url='';
    if(back==undefined){
      wx.reLaunch({
        url:'/pages/home/home'
      })
    }else{
      url="/"+back+'?lid='+lid+"&userName="+this.data.userName;
      wx.redirectTo({
        url: url
      })
    }
    //console.log(url);
  },
  //获取头像
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(1111)
    wx.getUserInfo({
      success: (res)=> {
        var userInfo = res.userInfo
        var avatarUrl = userInfo.avatarUrl
        this.setData({
          avatarUrl:avatarUrl
        })
      }
    })
    //console.log(options);
    if(options.lid==undefined){
      options.lid=1;
    }
    this.setData({
      back:options.back,
      lid:options.lid
    })
    //console.log(this.data.back,this.data.lid)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})